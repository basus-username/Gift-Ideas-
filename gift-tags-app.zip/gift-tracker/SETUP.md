# Gift Tags — Setup Guide (Vercel)

Same GitHub-connected flow you used for the bill splitter's Vercel deploy.

## 1. Push files to GitHub

Create a repo (e.g. `gift-tags`) and upload all files, keeping the structure exactly as-is:
```
index.html
manifest.json
sw.js
vercel.json
icons/icon-192.png
icons/icon-512.png
api/gift-ideas.js
```
The `api/gift-ideas.js` path matters — Vercel auto-detects anything in `/api` as a serverless function, don't rename or flatten that folder.

## 2. Import into Vercel

1. Vercel dashboard → Add New → Project → import the `gift-tags` GitHub repo.
2. Framework preset: "Other" (no build step needed — it's static HTML + one function).
3. Leave build command blank, output directory blank/root.
4. Deploy.

## 3. Add your Gemini API key

1. Project → Settings → Environment Variables.
2. Key: `GEMINI_API_KEY`, value: your Gemini key.
3. Redeploy (Deployments tab → ⋯ → Redeploy) so the function picks it up.

`vercel.json` already sets `maxDuration: 60` for the function, same fix you needed for the receipt scanner's timeout issue.

## 4. Install on your phone

Open the Vercel URL → "Add to Home Screen" (Safari) or the install prompt (Chrome/Android).

## What changed from the Netlify version

- Function moved from `netlify/functions/gift-ideas.js` to `api/gift-ideas.js`, using Vercel's `req`/`res` handler shape instead of Netlify's `event`/`handler` shape.
- Frontend now calls `/api/gift-ideas` instead of `/.netlify/functions/gift-ideas`.
- Added a **style/vibe chip picker** on the add/edit person screen — tap tags like "Homebody" or "Collector" instead of having to write a personality description. These get sent to the AI alongside your free-text notes.
- Rewrote the AI prompt to explicitly reject generic filler (mugs, candles, gift cards) unless your notes actually point there, and to avoid naming brands or sounding like ad copy — it's instructed to reason like a friend, not a marketer, and tie every idea to something specific you wrote.

## If AI suggestions fail

Check Vercel → your project → Functions → `gift-ideas` → logs. Same debugging pattern as before: usually a missing/wrong `GEMINI_API_KEY` or a rate limit.

## If ideas still feel off

The model can only work with what it's given — the more specific your notes (a recent complaint, what they spend weekends on) and style tags, the less it falls back to generic ground. If you find a phrase in the prompt still lets things slip through, tell me the actual bad suggestion and I can tighten the wording further.
